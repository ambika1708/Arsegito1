package com.example.airprepare;



public class Userlogin {

    String number;

    String password;



    public Userlogin(){



    }

    public Userlogin(String number,String password){

        this.number=number;

        this.password=password;

    }



    public String getNumber() {

        return number;

    }



    public String getPassword() {

        return password;

    }

}